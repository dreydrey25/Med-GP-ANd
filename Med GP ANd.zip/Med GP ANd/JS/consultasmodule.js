exports.myconsultas = function () {
    return("Consultas");
  };
  
