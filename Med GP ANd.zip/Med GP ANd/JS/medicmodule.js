exports.mymedicos = function () {
    return("Médicos");
  };
