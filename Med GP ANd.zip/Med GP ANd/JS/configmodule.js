exports.myconfig = function () {
    return("Configurações");
  };